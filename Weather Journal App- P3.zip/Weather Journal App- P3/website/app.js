/* Global Variables */

const feelings = document.getElementById('feelings');
const date = document.getElementById('date');
const temperature = document.getElementById('temp');
const country = document.getElementById('country');
const outcome_box = document.getElementById('content');

// We declare this veriable, for the data that we want to post, in part 2
const inputs = {};


// Create a new date instance dynamically with JS

let d = new Date();
let newDate = d.getMonth()+'.'+ d.getDate()+'.'+ d.getFullYear();




//-----------------------------------------------------------------------//
// PART 1 //

/* Function to POST data */

const postData = async ( url = '', data = {})=>{
	//console.log(data)
	  const response = await fetch(url, {
	  method: 'POST', 
	  credentials: 'same-origin', 
	  headers: {
		  'Content-Type': 'application/json',
	  },
	  body: JSON.stringify(data),         
	});
  
	  try {
		const newData = await response.json();
		return newData
	  }catch(error) {
	  console.log("error", error);
	  
	  }
}




//-----------------------------------------------------------------------//
// PART 2 //

// Acquire API credentials from OpenWeatherMap website


const base_url = 'http://api.openweathermap.org/data/2.5/weather?zip=';
const api_key= '&appid=b602e42b34cc40ff256428887f378a36&units=imperial';


document.getElementById('generate').addEventListener('click', performAction);
	
	
function performAction(e){
	const zip_code= document.getElementById('zip').value; 
	get_data(base_url,zip_code, api_key)

};


const get_data = async (base_url, zip_code, api_key)=>{
	const res = await fetch(base_url+zip_code+api_key)
	
	try {
		const data = await res.json();
		console.log(data)
		
		// Data we want to GET and POST:
		// Those data are either from (the web api or they are entered by the user).

		// Data from web api:
		inputs.country = `${(data.sys.country)}`;
		inputs.temperature = `${(data.main.temp - 273.15).toFixed(1)} °c`;

		// Data entered by the user:
		inputs.feelings = feelings.value;
		// Calling newDate var:
		inputs.date = newDate;

		console.log(inputs);
		// post data to the server and THEN apply (updateUI) function:
		postData('/add', inputs).then(updateUI())

		return data;

	}  catch(error) {
		console.log("error", error);
		
	}
}


//-----------------------------------------------------------------------//


// PART 3 //

// Updating UI function, to show the data we retrieved from our app on the DOM:

const updateUI = async () => {
	const request = await fetch('/all');
	try{
	  const data = await request.json();
	  date.innerHTML = `<p> Today's Date is: ${data.date}</p>`;
	  country.innerHTML = `<p> You Entered zip code for ${data.country} country</p>`;
	  temperature.innerHTML = `<p>The Temperature is: ${data.temperature}</p>`;
	  outcome_box.innerHTML = `<p>You are feeling: ${data.feelings}</p>`;
  
	}catch(error){
	  console.log("error", error);
	}
  }

  